// weapons
class Weapon {
	constructor(name, damage, className, image) {
		this.name = name;
		this.damage = damage;
		this.className = className;
		this.image = image;
	}
}

var quarter = new Weapon("quarter note", 10, "weapon-1", "quarter.png");
var eighth = new Weapon("eighth note", 5, "weapon-2", "eighth.png");
var half = new Weapon("half note", 20, "weapon-3", "half.png");
var whole = new Weapon("whole note", 40, "weapon-4", "whole.png");
var keyblack = new Weapon("keyblack", 15, "block", "black.png");


// players
const player1 = {
	position: {},
	currentWeapon: quarter,
	isDefending: false
};

const player2 = {
	position: {},
	currentWeapon: quarter,
	isDefending: false
};

// Generate random numbers
const generateRandomNum = () => Math.floor(Math.random() * 10);

// Generate grid with blocks
for (let i = 0; i < 10; i++) {
	for (let j = 0; j < 10; j++) {
		$('.grid-container').append('<div class="grid-item" data-y=' + i + ' data-x=' + j + '></div>');
	}
}

//Displays elements on the board
function generate(func, times) {
	for (let i = 0; i < Number(times); i++) {
		func();
	}
}
//Helps blocks, weapons and players find an available aquare in the board
function placeElements(className) {
	const random_x = generateRandomNum();
	const random_y = generateRandomNum();
	$('.grid-item').each(function () {
		const element = $(this);
		if (this.dataset['x'] == random_x && this.dataset['y'] == random_y) {
			if (!(this.classList.contains("unavailable"))) {
				element.addClass(className);
				element.addClass("unavailable");
				// updates the players' position values
				if (className === "player-1") {
					player1.position.x = this.dataset['x'];
					player1.position.y = this.dataset['y'];
				} else if (className === "player-2") {
					player2.position.x = this.dataset['x'];
					player2.position.y = this.dataset['y'];
				} else if (className === "weapon-1" ||
					className === "weapon-2" ||
					className === "weapon-3" ||
					className === "weapon-4") {
					element.addClass("weapon");
				}
				if (playerEncounter()) {
					console.log("Early Encounter");
					playerReset(className);
					placeElements(className);
				}
			} else {
				// Function calls itself until it finds an open space
				placeElements(className);
			}
		}
	});
}


function generateGame() {
	// Anonymous functions
	generate(function () {
		placeElements("block");
	}, 20);
	generate(function () {
		placeElements("weapon-1")
	}, 1);
	generate(function () {
		placeElements("weapon-2");
	}, 1);
	generate(function () {
		placeElements("weapon-3");
	}, 1);
	generate(function () {
		placeElements("weapon-4");
	}, 1);
	generate(function () {
		placeElements("keyblack");
	}, 8);
	generate(function () {
		placeElements("player-1");
	}, 1);
	generate(function () {
		placeElements("player-2");
	}, 1);
	movePlayer(player1);
	movePlayer(player2);
	pathHighlight();
	weaponDisplay(player1);
	weaponDisplay(player2);
}

function playerOneHighlight() {
	document.getElementById('playerOneTurn').style.color = "green";
	document.getElementById('playerTwoTurn').style.color = "white";
	//$('#aKey, #dKey').css("backgroundColor", "rgba(255, 19, 24, 0.55)");
}

function playerTwoHighlight() {
	document.getElementById('playerOneTurn').style.color = "white";
	document.getElementById('playerTwoTurn').style.color = "green";
	//$('#left, #right').css("backgroundColor", "rgba(0, 118, 255, 0.57)");
}


// Variable to check player movements
let playerTurn = true;

function pathHighlight() {
	if (playerTurn) {
		possiblePath(player1);
		$('.player-1').click(function () {
			$('.possible').css("background-color", "rgba(0, 255, 0, 0.6)");
		});
		playerOneHighlight();
	} else {
		possiblePath(player2);
		$('.player-2').click(function () {
			$('.possible').css("background-color", "rgba(0, 255, 0, 0.6)");
		});
		playerTwoHighlight();
	}
}

function movePlayer(player) {
	$('.grid-item').click(function () {
		pathHighlight();
		const element = $(this);
		const block = this;
		// Make sure desired path is within distance
		if (element.hasClass("possible")) {

			if (player === player2) {
				playerTwoHighlight();

				$('.player-2').click(function () {
					$('.possible').css("background-color", "rgba(0, 255, 0, 0.6)");
				});
				document.getElementById("rest").style.display = "none";

				if (!playerTurn) {
					playerOneHighlight();

					weaponChecker(block, player);
					handleWeapon(element, player);
					playerReset("player-2");
					element.addClass("player-2");
					handleFight();
					playerTurn = !playerTurn;
				}
			}


			if (player === player1) {
				playerOneHighlight();
				$('.player-1').click(function () {
					$('.possible').css("background-color", "rgba(0, 255, 0, 0.6)");
				});

				document.getElementById("rest2").style.display = "none";
				if (playerTurn) {

					weaponChecker(block, player);
					handleWeapon(element, player);
					playerReset("player-1");
					element.addClass("player-1");
					handleFight();
					playerTurn = !playerTurn;

				}
			}

		}

	});
}

function getPlayerPosition() {
	$('.grid-item').each(function () {
		const element = $(this);

		if (element.hasClass("player-1")) {
			player1.position.x = this.dataset['x'];
			player1.position.y = this.dataset['y'];
		}
		if (element.hasClass("player-2")) {
			player2.position.x = this.dataset['x'];
			player2.position.y = this.dataset['y'];
		}
	});
}


function playerReset(player) {
	$('.grid-item').each(function () {
		const element = $(this);
		element.removeClass(player);
		element.removeClass("possible");
		$('#aKey, #dKey, #left, #right').attr("disabled", false);
	});
}

function squareOccupied(element) {
	return (
		element.hasClass("block") ||
		element.hasClass("player-1") ||
		element.hasClass("player-2")
	);
}

function possiblePath(player) {
	$('.grid-item').each(function () {
		const element = $(this);
		const block = this;
		if (isInDistance(player, block) && !squareOccupied(element)) {
			element.addClass("possible");
		}
	});
	$('.grid-item').each(function () {
		const element = $(this);
		const block = this;
		// value with larger X
		if (isInDistance(player, block) && (block.dataset['x'] > player.position.x)) {
			//removing inDistance allows for diagonal movement 
			//if((block.dataset['x'] > player.position.x)){
			if (squareOccupied(element)) {
				occupiedObject = this;
				$('.possible').each(function () {
					const element = $(this);
					const block = this;

					if (block.dataset['x'] > occupiedObject.dataset['x']) {
						//	console.log("block x is greater than player x");
						element.removeClass("possible");
					}
				});
			}
		}
		// value with lower X
		if (isInDistance(player, block) && (block.dataset['x'] < player.position.x)) {

			if (squareOccupied(element)) {
				occupiedObject = this;
				$('.possible').each(function () {
					const element = $(this);
					const block = this;

					if (block.dataset['x'] < occupiedObject.dataset['x']) {
						//console.log("block x is less than player x");
						element.removeClass("possible");
					}
				});
			}
		}
		// value with higher y
		if (isInDistance(player, block) && (block.dataset['y'] > player.position.y)) {

			if (squareOccupied(element)) {
				occupiedObject = this;
				$('.possible').each(function () {
					const element = $(this);
					const block = this;

					if (block.dataset['y'] > occupiedObject.dataset['y']) {
						//console.log("block y is greater than player y");	
						element.removeClass("possible");
					}
				});
			}
		}
		// value with lower y
		if (isInDistance(player, block) && (block.dataset['y'] < player.position.y)) {

			if (squareOccupied(element)) {
				occupiedObject = this;
				$('.possible').each(function () {
					const element = $(this);
					const block = this;

					if (block.dataset['y'] < occupiedObject.dataset['y']) {
						//  console.log("block y is less than player y");
						//alert("up");
						element.removeClass("possible");
					}
				})
			}
		}
	})

	//removes color when tile outside of possible path is clicked
	$('.grid-item').each(function () {
		$('.possible').css("background-color", "");
	});


}
//if tiles have a block or player class, movement is not possible
function isInDistance(player, block) {
	const firstCondition = (Math.abs(block.dataset['x'] - player.position.x) < 4) &&
		(block.dataset['y'] === player.position.y);
	const secondCondition = (Math.abs(block.dataset['y'] - player.position.y) < 4) &&
		(block.dataset['x'] === player.position.x);
	return (firstCondition || secondCondition);
}

// Check if there are any weapons in the path
function weaponChecker(block, player) {
	checkSmallerX(block, player);
	checkSmallerY(block, player);
	checkLargerX(block, player);
	checkLargerY(block, player);
}

// Check if there is a weapon on the player's left
function checkSmallerX(block, player) {
	if (block.dataset['x'] < player.position.x) {
		$('.possible').each(function () {
			const element = $(this);
			const innerBlock = this;
			if ((innerBlock.dataset['x'] < player.position.x) &&
				(innerBlock.dataset['y'] == player.position.y) &&
				innerBlock.dataset['x'] > block.dataset['x']) {
				if (element.hasClass("weapon") ||

					element.hasClass("keyblack")) {
					weaponChange(element, player);;
				}
			}
		})
	}
}

// Check if there is a weapon on the player's right
function checkLargerX(block, player) {
	if (block.dataset['x'] > player.position.x) {
		$('.possible').each(function () {
			const element = $(this);
			const innerBlock = this;
			if ((innerBlock.dataset['x'] > player.position.x) &&
				(innerBlock.dataset['y'] == player.position.y) &&
				(innerBlock.dataset['x'] < block.dataset['x'])) {
				if (element.hasClass("weapon") ||

					element.hasClass("keyblack")) {
					weaponChange(element, player);
				}
			}
		})
	}
}

// Check if there is a weapon below the player
function checkSmallerY(block, player) {
	if (block.dataset['y'] < player.position.y) {
		$('.possible').each(function () {
			const element = $(this);
			const innerBlock = this;
			if ((innerBlock.dataset['y'] < player.position.y) &&
				(innerBlock.dataset['x'] == player.position.x) &&
				innerBlock.dataset['y'] > block.dataset['y']) {
				if (element.hasClass("weapon") ||

					element.hasClass("keyblack")) {
					weaponChange(element, player);
				}
			}
		})
	}
}

// Check if there is a weapon above the player
function checkLargerY(block, player) {
	if (block.dataset['y'] > player.position.y) {
		$('.possible').each(function () {
			const element = $(this);
			const innerBlock = this;
			if ((innerBlock.dataset['y'] > player.position.y) &&
				(innerBlock.dataset['x'] == player.position.x) &&
				innerBlock.dataset['y'] < block.dataset['y']) {
				if (element.hasClass("weapon") ||

					element.hasClass("keyblack")) {
					weaponChange(element, player);
				}
			}
		})
	}
}

var eighthNote = document.getElementById("eighth");
var quarterNote = document.getElementById("quarter");
var halfNote = document.getElementById("half");
var wholeNote = document.getElementById("whole");
var eNote = document.getElementById("enote");
var qNote = document.getElementById("qnote");
var hNote = document.getElementById("hnote");
var wNote = document.getElementById("wnote");

//if a weapon is landed on or passed over
//the old weapon is placed in the new weapon's place
function weaponChange(element, player) {
	let playerWeapon = player.currentWeapon;
	let damage = this.damage;
	if (element.hasClass("weapon-1")) {
		element.removeClass("weapon-1");
		element.addClass(playerWeapon.className);
		player.currentWeapon = quarter;
		weaponDisplay(player);
		quarter.damage = 10;

	} else if (element.hasClass("weapon-2")) {
		element.removeClass("weapon-2");
		element.addClass(playerWeapon.className);
		player.currentWeapon = eighth;
		weaponDisplay(player);
		eighth.damage = 5;

	} else if (element.hasClass("weapon-3")) {
		element.removeClass("weapon-3");
		element.addClass(playerWeapon.className);
		player.currentWeapon = half;
		weaponDisplay(player);
		half.damage = 20;

	} else if (element.hasClass("weapon-4")) {
		element.removeClass("weapon-4");
		element.addClass(playerWeapon.className);
		player.currentWeapon = whole;
		weaponDisplay(player);
		whole.damage = 40;

	} else if (element.hasClass("keyblack")) {
		if (player === player1) {
			document.getElementById("rest").style.display = "block"
			document.getElementById("myProgress").value -= 15;
			progressMeter();
			meterHealth();
		} else if (player === player2) {
			document.getElementById("rest2").style.display = "block"
			document.getElementById("myPro").value -= 15;
			proMeter();
			meterHealth();
		}
		element.removeClass("keyblack");
	}
}


function weaponDisplay(player) {
	if (player === player1) {

		if (player.currentWeapon == eighth) {
			eighthNote.style.display = "block";
		} else {
			eighthNote.style.display = "none";
		}

		if (player.currentWeapon == quarter) {
			quarterNote.style.display = "block";
		} else {
			quarterNote.style.display = "none";
		}
		if (player.currentWeapon == half) {
			halfNote.style.display = "block";
		} else {
			halfNote.style.display = "none";
		}
		if (player.currentWeapon == whole) {
			wholeNote.style.display = "block";
		} else {
			wholeNote.style.display = "none";
		}


	}
	if (player === player2) {
		if (player.currentWeapon == eighth) {
			eNote.style.display = "block";
		} else {
			eNote.style.display = "none";
		}

		if (player.currentWeapon == quarter) {
			qNote.style.display = "block";
		} else {
			qNote.style.display = "none";
		}
		if (player.currentWeapon == half) {
			hNote.style.display = "block";
		} else {
			hNote.style.display = "none";
		}
		if (player.currentWeapon == whole) {
			wNote.style.display = "block";
		} else {
			wNote.style.display = "none";
		}

	}
}

function handleWeapon(element, player) {
	weaponChange(element, player);
}

function playerEncounter() {
	getPlayerPosition();
	const xPosition = Math.abs(Number(player1.position.x) - Number(player2.position.x));
	const yPosition = Math.abs(Number(player2.position.y) - Number(player1.position.y));
	return (((xPosition == 0) && (yPosition == 1)) ||
		((yPosition == 0) && (xPosition == 1))
	)
}
//Player encounter/fight function
function handleFight() {
	if (playerEncounter()) {
$('.possible').css("background-color", "");
		$('.grid-item').each(function () {
			$('.grid-item').off();
			$('.possible').css("background-color", "");
		});

		$("#toggleButton").css("color", "green");
		$("#WASDmodal, #arrowKeysmodal").css("display", "block");
		$("#block, #block2").css("display", "none");
	
		const oneAttacks = document.getElementById('aKey');
		const twoAttacks = document.getElementById('left');
		const oneDefends = document.getElementById('dKey');
		const twoDefends = document.getElementById('right');

		if (!playerTurn) {

			$('#aKey, #dKey').attr("disabled", false).css("backgroundColor", "rgba(255, 19, 24, 0.55)");
			$('#left, #right').css("color", "");
		}

		oneAttacks.onclick = function () {
			playerReset(player1);
			meterHealth();
			proMeter();
			proBar.value -= player1.currentWeapon.damage;
			$('#aKey, #dKey').attr("disabled", true).css("backgroundColor", "");
		
			playerTwoHighlight();
			$('#left, #right').css("backgroundColor", "rgba(0, 118, 255, 0.57)");
		}

		oneDefends.onclick = function () {
			playerReset(player1);
			meterHealth();
			progressMeter();
			backBar.value -= player2.currentWeapon.damage / 2;
			$('#dKey, #aKey').attr("disabled", true).css("backgroundColor", "");
		
			playerTwoHighlight();
			$('#left, #right').css("backgroundColor", "rgba(0, 118, 255, 0.57)");
		}

		if (playerTurn) {

			$('#left, #right').attr("disabled", false).css("backgroundColor", "rgba(0, 118, 255, 0.57)");
			$('#aKey, #dKey').css("color", "");
		}

		twoAttacks.onclick = function () {
			playerReset(player2);
			meterHealth();
			progressMeter();
			backBar.value -= player2.currentWeapon.damage;
			$('#left, #right').attr("disabled", true).css("backgroundColor", "");
			
			playerOneHighlight();
			$('#aKey, #dKey').css("backgroundColor", "rgba(255, 19, 24, 0.55)");
			
		}

		twoDefends.onclick = function () {
			playerReset(player2);
			meterHealth();
			proMeter();
			proBar.value -= player1.currentWeapon.damage / 2;
			$('#right').attr("disabled", true).css("backgroundColor", "");
			$('#left').attr("disabled", true).css("backgroundColor", "");

			playerOneHighlight();
			$('#aKey, #dKey').css("backgroundColor", "rgba(255, 19, 24, 0.55)");
		}
	} else if (!playerEncounter()) {
		$("#toggleButton").css("color", "");
		$("#WASDmodal, #arrowKeysmodal").css("display", "none");
		$("#block, #block2").css("display", "block");
		$('#right, #left, #dKey, #aKey').attr("disabled", true);
	}
}
//Health percentage/ player status
function meterHealth() {
	handleFight();
	if (backBar.value <= 0) {
		backBar.value = 0;
		window.open('beethoven.html', "_self");
	}

	if (proBar.value <= 0) {
		proBar.value = 0;
		window.open('mozart.html', "_self");
	}
}